import React from 'react';
import { FileText, Presentation as PresentationChart, Calendar, Eye, MessageCircle } from 'lucide-react';

interface Material {
  id: string;
  name: string;
  type: string;
  size: number;
  uploadedAt: string;
  processed: boolean;
  contentSummary: string;
  pageCount: number;
}

interface MaterialsLibraryProps {
  materials: Material[];
  onMaterialSelect: (material: Material) => void;
}

const MaterialsLibrary: React.FC<MaterialsLibraryProps> = ({ materials, onMaterialSelect }) => {
  const formatFileSize = (bytes: number) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
    });
  };

  const getFileIcon = (type: string) => {
    return type.includes('pdf') ? FileText : PresentationChart;
  };

  const getFileTypeColor = (type: string) => {
    return type.includes('pdf') ? 'bg-red-100 text-red-800' : 'bg-orange-100 text-orange-800';
  };

  if (materials.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="bg-gray-100 rounded-full w-24 h-24 flex items-center justify-center mx-auto mb-4">
          <FileText className="w-12 h-12 text-gray-400" />
        </div>
        <h3 className="text-lg font-medium text-gray-900 mb-2">No materials uploaded yet</h3>
        <p className="text-gray-600 mb-6">
          Upload your first PDF or PowerPoint presentation to get started
        </p>
        <button
          onClick={() => window.location.reload()}
          className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 transition-colors"
        >
          Upload Materials
        </button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Materials Library</h2>
          <p className="text-gray-600">
            {materials.length} material{materials.length !== 1 ? 's' : ''} available for learning
          </p>
        </div>
        <div className="flex items-center space-x-2">
          <span className="text-sm text-gray-500">Total size:</span>
          <span className="text-sm font-medium text-gray-900">
            {formatFileSize(materials.reduce((sum, m) => sum + m.size, 0))}
          </span>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {materials.map((material) => {
          const Icon = getFileIcon(material.type);
          const typeColorClass = getFileTypeColor(material.type);

          return (
            <div
              key={material.id}
              className="bg-white rounded-lg shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow cursor-pointer"
              onClick={() => onMaterialSelect(material)}
            >
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-3">
                  <div className="bg-gray-100 p-2 rounded-lg">
                    <Icon className="w-6 h-6 text-gray-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-lg font-medium text-gray-900 truncate">
                      {material.name}
                    </h3>
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${typeColorClass}`}>
                      {material.type.includes('pdf') ? 'PDF' : 'PPT'}
                    </span>
                  </div>
                </div>
              </div>

              <div className="space-y-3">
                <p className="text-sm text-gray-600 line-clamp-2">
                  {material.contentSummary}
                </p>

                <div className="flex items-center justify-between text-sm text-gray-500">
                  <div className="flex items-center space-x-1">
                    <Calendar className="w-4 h-4" />
                    <span>{formatDate(material.uploadedAt)}</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Eye className="w-4 h-4" />
                    <span>{material.pageCount} pages</span>
                  </div>
                </div>

                <div className="flex items-center justify-between text-sm text-gray-500">
                  <span>{formatFileSize(material.size)}</span>
                  <div className="flex items-center space-x-1">
                    {material.processed ? (
                      <span className="text-emerald-600 font-medium">Ready</span>
                    ) : (
                      <span className="text-amber-600 font-medium">Processing...</span>
                    )}
                  </div>
                </div>
              </div>

              <div className="mt-4 pt-4 border-t border-gray-200">
                <div className="flex items-center justify-between">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onMaterialSelect(material);
                    }}
                    className="inline-flex items-center px-3 py-2 border border-transparent text-sm font-medium rounded-md text-blue-700 bg-blue-100 hover:bg-blue-200 transition-colors"
                  >
                    <MessageCircle className="w-4 h-4 mr-2" />
                    Start Learning
                  </button>
                  <div className="flex items-center space-x-2">
                    <div className="w-2 h-2 bg-emerald-500 rounded-full"></div>
                    <span className="text-xs text-gray-500">AI Ready</span>
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default MaterialsLibrary;
