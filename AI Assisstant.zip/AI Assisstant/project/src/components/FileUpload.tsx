import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import {
  Upload,
  FileText,
  Presentation as PresentationChart,
  CheckCircle,
  AlertCircle,
  Loader,
  Brain,
  MessageCircle,
} from 'lucide-react';

interface FileUploadProps {
  onFileUpload: (files: any[]) => void;
}

const FileUpload: React.FC<FileUploadProps> = ({ onFileUpload }) => {
  const [uploadProgress, setUploadProgress] = useState<{ [key: string]: number }>({});
  const [uploadStatus, setUploadStatus] = useState<{ [key: string]: 'uploading' | 'success' | 'error' }>({});

  const onDrop = useCallback(async (acceptedFiles: File[]) => {
    const processedFiles: any[] = [];

    for (const file of acceptedFiles) {
      const fileId = `${file.name}_${Date.now()}`;
      setUploadStatus(prev => ({ ...prev, [fileId]: 'uploading' }));

      try {
        for (let progress = 0; progress <= 100; progress += 20) {
          setUploadProgress(prev => ({ ...prev, [fileId]: progress }));
          await new Promise(resolve => setTimeout(resolve, 200));
        }

        // Mock processed file
        const processedFile = {
          id: fileId,
          name: file.name,
          type: file.type,
          size: file.size,
          uploadedAt: new Date().toISOString(),
          processed: true,
          contentSummary: `This is a ${file.type.includes('pdf') ? 'PDF document' : 'PowerPoint presentation'} containing educational content.`,
          pageCount: Math.floor(Math.random() * 50) + 10,
        };

        processedFiles.push(processedFile);
        setUploadStatus(prev => ({ ...prev, [fileId]: 'success' }));
      } catch (error) {
        console.error('Upload error:', error);
        setUploadStatus(prev => ({ ...prev, [fileId]: 'error' }));
      }
    }

    onFileUpload(processedFiles);

    // Clear progress and status after 2 seconds
    setTimeout(() => {
      setUploadProgress({});
      setUploadStatus({});
    }, 2000);
  }, [onFileUpload]);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      'application/pdf': ['.pdf'],
      'application/vnd.ms-powerpoint': ['.ppt'],
      'application/vnd.openxmlformats-officedocument.presentationml.presentation': ['.pptx'],
    },
    maxSize: 50 * 1024 * 1024,
  });

  const getFileIcon = (type: string) => (type.includes('pdf') ? FileText : PresentationChart);

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Upload Learning Materials</h2>
        <p className="text-gray-600">
          Upload PDFs and PowerPoint presentations to start your interactive learning experience
        </p>
      </div>

      <div
        {...getRootProps()}
        className={`border-2 border-dashed rounded-xl p-12 text-center cursor-pointer transition-all duration-200 ${
          isDragActive
            ? 'border-blue-400 bg-blue-50'
            : 'border-gray-300 hover:border-gray-400 hover:bg-gray-50'
        }`}
      >
        <input {...getInputProps()} />
        <div className="flex flex-col items-center space-y-4">
          <div className="bg-blue-100 p-4 rounded-full">
            <Upload className="w-8 h-8 text-blue-600" />
          </div>
          <p className="text-lg font-medium text-gray-900">
            {isDragActive ? 'Drop files here' : 'Drag & drop files here'}
          </p>
          <p className="text-gray-600">or click to select files</p>
          <div className="text-sm text-gray-500">
            Supported formats: PDF, PPT, PPTX (Max 50MB)
          </div>
        </div>
      </div>

      {/* Upload Progress */}
      {Object.keys(uploadProgress).length > 0 && (
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-6">
          <h3 className="text-lg font-medium text-gray-900 mb-4">Upload Progress</h3>
          <div className="space-y-4">
            {Object.entries(uploadProgress).map(([fileId, progress]) => {
              const fileName = fileId.split('_')[0];
              const status = uploadStatus[fileId];
              const Icon = getFileIcon(fileName);

              return (
                <div key={fileId} className="flex items-center space-x-3">
                  <Icon className="w-5 h-5 text-gray-600" />
                  <div className="flex-1">
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-sm font-medium text-gray-900">{fileName}</span>
                      <div className="flex items-center space-x-2">
                        {status === 'uploading' && <Loader className="w-4 h-4 text-blue-600 animate-spin" />}
                        {status === 'success' && <CheckCircle className="w-4 h-4 text-emerald-600" />}
                        {status === 'error' && <AlertCircle className="w-4 h-4 text-red-600" />}
                        <span className="text-sm text-gray-600">{progress}%</span>
                      </div>
                    </div>
                    <div className="bg-gray-200 rounded-full h-2">
                      <div
                        className={`h-2 rounded-full transition-all duration-300 ${
                          status === 'success' ? 'bg-emerald-600' :
                          status === 'error' ? 'bg-red-600' :
                          'bg-blue-600'
                        }`}
                        style={{ width: `${progress}%` }}
                      />
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Instructions */}
      <div className="bg-gradient-to-r from-blue-50 to-emerald-50 rounded-lg p-6 border border-blue-200">
        <h3 className="text-lg font-medium text-gray-900 mb-3">What happens after upload?</h3>
        <div className="grid md:grid-cols-2 gap-4">
          <div className="flex items-start space-x-3">
            <div className="bg-blue-100 p-2 rounded-lg">
              <Brain className="w-5 h-5 text-blue-600" />
            </div>
            <div>
              <p className="font-medium text-gray-900">AI Processing</p>
              <p className="text-sm text-gray-600">
                Your materials are analyzed by AI to understand the content and structure
              </p>
            </div>
          </div>
          <div className="flex items-start space-x-3">
            <div className="bg-emerald-100 p-2 rounded-lg">
              <MessageCircle className="w-5 h-5 text-emerald-600" />
            </div>
            <div>
              <p className="font-medium text-gray-900">Interactive Q&A</p>
              <p className="text-sm text-gray-600">
                Ask questions and get instant answers from your uploaded materials
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FileUpload;
