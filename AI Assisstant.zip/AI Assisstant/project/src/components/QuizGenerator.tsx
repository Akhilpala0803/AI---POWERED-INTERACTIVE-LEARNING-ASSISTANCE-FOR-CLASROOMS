import React, { useState } from 'react';
import { Brain, CheckCircle, XCircle, RefreshCw, Award, Target, Clock } from 'lucide-react';

interface Question {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  topic: string;
}

interface QuizGeneratorProps {
  currentMaterial: any;
}

const QuizGenerator: React.FC<QuizGeneratorProps> = ({ currentMaterial }) => {
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<{ [key: string]: number }>({});
  const [showResults, setShowResults] = useState(false);
  const [quizStarted, setQuizStarted] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [numQuestions, setNumQuestions] = useState(10);

  const generateQuiz = async () => {
    setIsGenerating(true);
    
    // Simulate quiz generation
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const sampleQuestions: Question[] = [
      {
        id: '1',
        question: 'What is the primary purpose of the concept discussed in chapter 1?',
        options: [
          'To provide a theoretical framework',
          'To establish practical applications',
          'To analyze historical context',
          'To compare different methodologies'
        ],
        correctAnswer: 1,
        explanation: 'The primary purpose is to establish practical applications as outlined in the introduction section. This concept serves as the foundation for real-world implementation.',
        difficulty: 'Easy',
        topic: 'Fundamental Concepts'
      },
      {
        id: '2',
        question: 'Which of the following best describes the relationship between the key components?',
        options: [
          'They operate independently',
          'They work in a sequential manner',
          'They function as an integrated system',
          'They are mutually exclusive'
        ],
        correctAnswer: 2,
        explanation: 'The components function as an integrated system where each part contributes to the overall functionality, as demonstrated in the case studies.',
        difficulty: 'Medium',
        topic: 'System Integration'
      },
      {
        id: '3',
        question: 'What are the main advantages of implementing this approach?',
        options: [
          'Cost reduction only',
          'Improved efficiency and scalability',
          'Simplified maintenance procedures',
          'Enhanced security features'
        ],
        correctAnswer: 1,
        explanation: 'The main advantages include improved efficiency and scalability, which are highlighted throughout the document with supporting data and examples.',
        difficulty: 'Medium',
        topic: 'Implementation Benefits'
      },
      {
        id: '4',
        question: 'In the advanced section, what critical factor must be considered?',
        options: [
          'Budget constraints',
          'Technical specifications',
          'User requirements and system compatibility',
          'Timeline limitations'
        ],
        correctAnswer: 2,
        explanation: 'User requirements and system compatibility are critical factors as they determine the success of implementation, as detailed in the advanced section.',
        difficulty: 'Hard',
        topic: 'Advanced Considerations'
      }
    ];

    // Generate additional questions based on numQuestions
    const generatedQuestions = [];
    for (let i = 0; i < numQuestions; i++) {
      const baseQuestion = sampleQuestions[i % sampleQuestions.length];
      generatedQuestions.push({
        ...baseQuestion,
        id: `q_${i + 1}`,
        question: `${baseQuestion.question} (Question ${i + 1})`,
      });
    }

    setQuestions(generatedQuestions);
    setIsGenerating(false);
    setQuizStarted(true);
  };

  const handleAnswerSelect = (questionId: string, answerIndex: number) => {
    setSelectedAnswers(prev => ({
      ...prev,
      [questionId]: answerIndex
    }));
  };

  const handleNext = () => {
    if (currentQuestionIndex < questions.length - 1) {
      setCurrentQuestionIndex(currentQuestionIndex + 1);
    } else {
      setShowResults(true);
    }
  };

  const handlePrevious = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(currentQuestionIndex - 1);
    }
  };

  const calculateScore = () => {
    let correct = 0;
    questions.forEach(question => {
      if (selectedAnswers[question.id] === question.correctAnswer) {
        correct++;
      }
    });
    return { correct, total: questions.length, percentage: Math.round((correct / questions.length) * 100) };
  };

  const resetQuiz = () => {
    setQuestions([]);
    setCurrentQuestionIndex(0);
    setSelectedAnswers({});
    setShowResults(false);
    setQuizStarted(false);
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Easy': return 'bg-green-100 text-green-800';
      case 'Medium': return 'bg-yellow-100 text-yellow-800';
      case 'Hard': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (!currentMaterial) {
    return (
      <div className="text-center py-12">
        <div className="bg-purple-100 rounded-full w-24 h-24 flex items-center justify-center mx-auto mb-4">
          <Brain className="w-12 h-12 text-purple-600" />
        </div>
        <h3 className="text-lg font-medium text-gray-900 mb-2">Select a material to generate quiz</h3>
        <p className="text-gray-600 mb-6">
          Choose from your uploaded materials to create personalized quizzes
        </p>
      </div>
    );
  }

  if (showResults) {
    const score = calculateScore();
    return (
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8 text-center">
          <div className="mb-6">
            <div className="bg-blue-100 rounded-full w-24 h-24 flex items-center justify-center mx-auto mb-4">
              <Award className="w-12 h-12 text-blue-600" />
            </div>
            <h2 className="text-3xl font-bold text-gray-900 mb-2">Quiz Complete!</h2>
            <p className="text-gray-600">Here are your results</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
            <div className="bg-green-50 rounded-lg p-6">
              <div className="text-2xl font-bold text-green-600 mb-2">{score.correct}</div>
              <div className="text-sm text-green-800">Correct Answers</div>
            </div>
            <div className="bg-blue-50 rounded-lg p-6">
              <div className="text-2xl font-bold text-blue-600 mb-2">{score.percentage}%</div>
              <div className="text-sm text-blue-800">Overall Score</div>
            </div>
            <div className="bg-purple-50 rounded-lg p-6">
              <div className="text-2xl font-bold text-purple-600 mb-2">{score.total}</div>
              <div className="text-sm text-purple-800">Total Questions</div>
            </div>
          </div>

          <div className="space-y-4 mb-8">
            <h3 className="text-lg font-medium text-gray-900">Question Review</h3>
            {questions.map((question, index) => {
              const userAnswer = selectedAnswers[question.id];
              const isCorrect = userAnswer === question.correctAnswer;
              
              return (
                <div key={question.id} className="bg-gray-50 rounded-lg p-4 text-left">
                  <div className="flex items-start justify-between mb-2">
                    <h4 className="text-md font-medium text-gray-900">
                      {index + 1}. {question.question}
                    </h4>
                    {isCorrect ? (
                      <CheckCircle className="w-5 h-5 text-green-600 flex-shrink-0" />
                    ) : (
                      <XCircle className="w-5 h-5 text-red-600 flex-shrink-0" />
                    )}
                  </div>
                  <div className="text-sm text-gray-600 mb-2">
                    <span className="font-medium">Your answer:</span> {question.options[userAnswer]}
                  </div>
                  {!isCorrect && (
                    <div className="text-sm text-gray-600 mb-2">
                      <span className="font-medium">Correct answer:</span> {question.options[question.correctAnswer]}
                    </div>
                  )}
                  <div className="text-sm text-gray-700 bg-white p-2 rounded border-l-4 border-blue-400">
                    <span className="font-medium">Explanation:</span> {question.explanation}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="flex justify-center space-x-4">
            <button
              onClick={resetQuiz}
              className="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 transition-colors"
            >
              <RefreshCw className="w-5 h-5 mr-2" />
              Generate New Quiz
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (quizStarted && questions.length > 0) {
    const currentQuestion = questions[currentQuestionIndex];
    const progress = ((currentQuestionIndex + 1) / questions.length) * 100;

    return (
      <div className="max-w-4xl mx-auto">
        <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8">
          {/* Progress Bar */}
          <div className="mb-6">
            <div className="flex justify-between items-center mb-2">
              <span className="text-sm font-medium text-gray-700">
                Question {currentQuestionIndex + 1} of {questions.length}
              </span>
              <span className="text-sm text-gray-500">{Math.round(progress)}% Complete</span>
            </div>
            <div className="w-full bg-gray-200 rounded-full h-2">
              <div
                className="bg-blue-600 h-2 rounded-full transition-all duration-300"
                style={{ width: `${progress}%` }}
              />
            </div>
          </div>

          {/* Question */}
          <div className="mb-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold text-gray-900">{currentQuestion.question}</h2>
              <div className="flex items-center space-x-2">
                <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${getDifficultyColor(currentQuestion.difficulty)}`}>
                  {currentQuestion.difficulty}
                </span>
                <span className="text-sm text-gray-500">{currentQuestion.topic}</span>
              </div>
            </div>

            <div className="space-y-3">
              {currentQuestion.options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => handleAnswerSelect(currentQuestion.id, index)}
                  className={`w-full text-left p-4 rounded-lg border-2 transition-colors ${
                    selectedAnswers[currentQuestion.id] === index
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  <div className="flex items-center space-x-3">
                    <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center ${
                      selectedAnswers[currentQuestion.id] === index
                        ? 'border-blue-500 bg-blue-500'
                        : 'border-gray-300'
                    }`}>
                      {selectedAnswers[currentQuestion.id] === index && (
                        <div className="w-2 h-2 bg-white rounded-full" />
                      )}
                    </div>
                    <span className="text-gray-900">{option}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>

          {/* Navigation */}
          <div className="flex justify-between items-center">
            <button
              onClick={handlePrevious}
              disabled={currentQuestionIndex === 0}
              className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              Previous
            </button>
            <button
              onClick={handleNext}
              disabled={selectedAnswers[currentQuestion.id] === undefined}
              className="inline-flex items-center px-4 py-2 border border-transparent rounded-md text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              {currentQuestionIndex === questions.length - 1 ? 'Finish Quiz' : 'Next'}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Generate Quiz</h2>
        <p className="text-gray-600">
          Create personalized quizzes from your uploaded material: {currentMaterial.name}
        </p>
      </div>

      <div className="bg-white rounded-lg shadow-sm border border-gray-200 p-8">
        <div className="space-y-6">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Number of Questions
            </label>
            <select
              value={numQuestions}
              onChange={(e) => setNumQuestions(parseInt(e.target.value))}
              className="block w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
            >
              <option value={5}>5 Questions</option>
              <option value={10}>10 Questions</option>
              <option value={20}>20 Questions</option>
              <option value={50}>50 Questions</option>
              <option value={100}>100 Questions</option>
            </select>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="bg-green-50 rounded-lg p-6 text-center">
              <Target className="w-8 h-8 text-green-600 mx-auto mb-2" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Adaptive Difficulty</h3>
              <p className="text-sm text-gray-600">
                Questions adapt to your learning progress
              </p>
            </div>
            <div className="bg-blue-50 rounded-lg p-6 text-center">
              <Brain className="w-8 h-8 text-blue-600 mx-auto mb-2" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">AI-Generated</h3>
              <p className="text-sm text-gray-600">
                Intelligent questions from your material
              </p>
            </div>
            <div className="bg-purple-50 rounded-lg p-6 text-center">
              <Clock className="w-8 h-8 text-purple-600 mx-auto mb-2" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">Instant Feedback</h3>
              <p className="text-sm text-gray-600">
                Detailed explanations for each answer
              </p>
            </div>
          </div>

          <div className="text-center">
            <button
              onClick={generateQuiz}
              disabled={isGenerating}
              className="inline-flex items-center px-8 py-3 border border-transparent text-base font-medium rounded-md text-white bg-gradient-to-r from-blue-600 to-emerald-600 hover:from-blue-700 hover:to-emerald-700 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
            >
              {isGenerating ? (
                <>
                  <RefreshCw className="w-5 h-5 mr-2 animate-spin" />
                  Generating Quiz...
                </>
              ) : (
                <>
                  <Brain className="w-5 h-5 mr-2" />
                  Generate Quiz
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default QuizGenerator;